---
name: Precision Print Narrative
colors:
  surface: '#fff8f7'
  surface-dim: '#f4d3cf'
  surface-bright: '#fff8f7'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff0ee'
  surface-container: '#ffe9e6'
  surface-container-high: '#ffe2de'
  surface-container-highest: '#fcdbd7'
  on-surface: '#291715'
  on-surface-variant: '#5d3f3c'
  inverse-surface: '#402b29'
  inverse-on-surface: '#ffedea'
  outline: '#926f6b'
  outline-variant: '#e7bdb8'
  surface-tint: '#c00015'
  primary: '#bd0014'
  on-primary: '#ffffff'
  primary-container: '#e42327'
  on-primary-container: '#fffdff'
  inverse-primary: '#ffb4ac'
  secondary: '#5e5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e2e2e2'
  on-secondary-container: '#646464'
  tertiary: '#735c00'
  on-tertiary: '#ffffff'
  tertiary-container: '#cfa700'
  on-tertiary-container: '#4e3e00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad6'
  primary-fixed-dim: '#ffb4ac'
  on-primary-fixed: '#410002'
  on-primary-fixed-variant: '#93000d'
  secondary-fixed: '#e2e2e2'
  secondary-fixed-dim: '#c6c6c6'
  on-secondary-fixed: '#1b1b1b'
  on-secondary-fixed-variant: '#474747'
  tertiary-fixed: '#ffe087'
  tertiary-fixed-dim: '#f0c100'
  on-tertiary-fixed: '#231a00'
  on-tertiary-fixed-variant: '#574500'
  background: '#fff8f7'
  on-background: '#291715'
  surface-variant: '#fcdbd7'
typography:
  display-lg:
    fontFamily: epilogue
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: epilogue
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 42px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: epilogue
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-sm:
    fontFamily: epilogue
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: montserrat
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: montserrat
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: montserrat
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: jetbrainsMono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: jetbrainsMono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.05em
spacing:
  base: 4px
  unit-1: 0.25rem
  unit-2: 0.5rem
  unit-4: 1rem
  unit-8: 2rem
  gutter: 1.5rem
  margin: 2rem
  max-width: 1440px
---

## Brand & Style

The design system is built upon the **Precision Print Narrative**, a style that bridges the gap between high-output industrial utility and modern digital refinement. It targets professional environments where accuracy, speed, and reliability are paramount, such as print production, engineering hubs, or logistics management. 

The aesthetic is **Modern-Industrial Minimalism**. It utilizes a stark, high-contrast palette to create a "heads-up display" feel that is both authoritative and efficient. By blending the bold, structured impact of Swiss-style poster design with the functional clarity of modern SaaS, the UI evokes a sense of technical mastery and immediate response. The emotional goal is to make the user feel in complete control of a high-performance machine.

## Colors

The color palette is restricted and purposeful, mirroring the ink channels of a high-end press. 

- **Primary Red (#e42327):** Used for critical actions, brand accents, and active states. It demands attention and signals "System Active."
- **Black (#000000):** Used for primary text and structural borders to ensure maximum legibility and a grounded, technical feel.
- **White (#ffffff):** The base surface. It provides the "paper" onto which the data is printed, ensuring a clean, high-contrast workspace.
- **Yellow (#ffce07):** A secondary accent used for warnings, status highlights, and secondary information that requires visual separation without the urgency of red.
- **Green (#00B201):** Specifically reserved for "Ready," "Complete," or "Optimal" states, providing a clear functional contrast to the primary red.

## Typography

The typography system uses a mix of fonts to replicate the hierarchy of technical documentation and architectural blueprints.

- **Display & Headings:** Using **Epilogue** (substituting for UTM Cafeta) to provide a bold, condensed, and architectural presence. It is used for large titles and section headers to create a strong vertical rhythm.
- **Body:** **Montserrat** (substituting for SVN Gotham) serves as the primary workhorse. Its geometric sans-serif nature maintains clarity across long-form data and status reports.
- **Labels & Data:** **JetBrains Mono** is introduced for technical metadata, values, and status labels. The monospaced nature reinforces the precision and "machine-read" aspect of the design system.

## Layout & Spacing

The design system utilizes a **Fixed Grid** model on desktop to maintain strict alignment, transitioning to a fluid model on mobile. 

- **The 4px Baseline:** All spacing is derived from a 4px increment. This ensures that every element, from the height of a button to the padding of a card, feels mathematically intentional.
- **Desktop:** A 12-column grid with a 1440px max-width. Gutters are kept tight (24px) to emphasize a dense, information-rich environment.
- **Mobile:** A 4-column grid with 16px margins. Content should stack vertically, prioritizing data readouts over complex side-by-side layouts.
- **Alignment:** Use heavy vertical and horizontal lines (1px Black) to delineate sections, rather than whitespace alone, mimicking the "blocks" of a print layout.

## Elevation & Depth

To maintain the "Precision Print" feel, this design system avoids soft shadows and organic blurs. Depth is achieved through **Tonal Layering and Bold Borders**.

- **Flat Depth:** Use a "Plano" approach. Surfaces do not float; they are nested. 
- **Borders as Depth:** Hierarchy is established through border weight. A primary container has a 2px Black border, while nested elements use 1px.
- **Active States:** Instead of a shadow, an "elevated" or "active" element is filled with a high-contrast color (Primary Red or Yellow) or given a thick 4px offset "block shadow" in solid black (Hard Shadow).
- **Inlays:** Use a light grey (#F2F2F2) background for recessed areas like input fields or secondary sidebars to create a "punched-out" effect.

## Shapes

In line with the industrial and technical theme, the shape language is **Sharp (0px)**. 

Every element—buttons, cards, input fields, and tags—must have 90-degree corners. This evokes the precision of a paper cutter and the rigidity of hardware components. There are no exceptions for "rounded-lg" or "pill" shapes; all UI components remain strictly rectangular to maintain a consistent, unyielding aesthetic.

## Components

- **Buttons:** Rectangular with 2px black borders. Primary buttons are solid Red with White text. Secondary buttons are White with Black borders and Black text. On hover, buttons should "invert" (e.g., Red becomes Black).
- **Input Fields:** 1px Black border with a 4px left-hand color strip (Primary Red) to indicate focus. Use JetBrains Mono for input text.
- **Chips/Status Tags:** Solid Black backgrounds with White monospaced text for a "Dymo label" look. Use Yellow or Green backgrounds for specific status alerts.
- **Cards:** Defined by a 1px Black border. Headers should have a solid Black background with White text to act as a "handle" for the content block.
- **Lists:** Separated by 1px horizontal rules. Interactive list items should highlight in Yellow on hover to provide a high-contrast tracking guide for the user's eye.
- **Gauges & Meters:** Use blocky, segmented progress bars rather than smooth gradients to represent data loading or mechanical capacity.